# Anaya Hall
# CCE - Fall 2017
# Assignment 5 : Economic Growth

using Mimi

@defcomp damages begin

end

function run_timestep(state::damages, t::Int64)
    v = state.Variables
    p = state.Parameters

end